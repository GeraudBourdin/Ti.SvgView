//
//  SVGKParserPatternsAndGradients.h
//  SVGKit
//
//  Created by adam applecansuckmybigtodger on 28/06/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SVGKParser.h"

@interface SVGKParserPatternsAndGradients : NSObject <SVGKParserExtension>

@end
